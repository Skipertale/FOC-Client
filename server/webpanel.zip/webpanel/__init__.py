import asyncio
import csv
import io
import json
import logging
import sys
import time
from pathlib import Path
from datetime import datetime, timedelta

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, FileResponse, StreamingResponse
from jinja2 import Environment, FileSystemLoader

from server import database as db

logger = logging.getLogger("webpanel")

HERE = Path(__file__).resolve().parent
_crm_db_path = None
templates = Environment(loader=FileSystemLoader(str(HERE)))

# Import CRM repository
sys.path.insert(0, str(HERE.parent.parent))
try:
    from admin_crm.app import CRMRepository
    _crm_repo = None
except ImportError as e:
    logger.warning("CRM import failed: %s", e)
    CRMRepository = None
    _crm_repo = None

_ws_clients = set()
_server_ref = None
_config = {}
_webpanel_running = False


def broadcast_event(event_type, data):
    if not _webpanel_running:
        return
    msg = json.dumps({"type": event_type, **data})
    for ws in list(_ws_clients):
        try:
            asyncio.ensure_future(ws.send_text(msg))
        except Exception:
            _ws_clients.discard(ws)


def render(name, **kwargs):
    tpl = templates.get_template(name)
    return HTMLResponse(tpl.render(**{**kwargs, "cfg": _config}), media_type="text/html; charset=utf-8")


def _auth(request: Request):
    if not _crm_repo:
        return None
    token = request.cookies.get("wp_session") or request.cookies.get("crm_session")
    if token:
        try:
            acc = _crm_repo.get_account_by_session(token)
            if acc and _crm_repo.has_panel_access(acc):
                return True
        except Exception:
            pass
    return None


def _account(request: Request):
    token = request.cookies.get("wp_session") or request.cookies.get("crm_session")
    if token and _crm_repo:
        try:
            acc = _crm_repo.get_account_by_session(token)
            if acc:
                return dict(acc)
        except Exception:
            pass
    return None


def _cli(ipid):
    srv = _server_ref
    if not srv:
        return None
    for c in srv.client_manager.clients:
        if c.ipid == ipid:
            return c
    return None


def _log_admin(action, data=None):
    try:
        from server import database as db
        db.log_misc("admin_action", data={"action": action, **(data or {})})
    except Exception:
        pass


def make_app(server, cfg):
    global _server_ref, _config, _webpanel_running, _crm_db_path, _crm_repo
    _server_ref = server
    _config = cfg
    _webpanel_running = True
    _crm_db_path = cfg.get("crm_db") or None
    if CRMRepository and not _crm_repo:
        try:
            _crm_repo = CRMRepository(
                source_db=HERE.parent.parent / "storage" / "db.sqlite3",
                crm_db=Path(_crm_db_path) if _crm_db_path else (HERE.parent.parent / "admin_crm" / "crm.sqlite3"),
            )
            _crm_repo.maybe_start_auto_sync()
            logger.info("CRM repository initialized")
        except Exception as e:
            logger.warning("CRM init failed: %s", e)

    app = FastAPI(title="KFO-Server Web Panel")

    @app.get("/style.css")
    async def css():
        return FileResponse(str(HERE / "style.css"))

    @app.get("/app.js")
    async def js():
        return FileResponse(str(HERE / "app.js"))

    @app.get("/")
    async def index(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("dashboard.html")

    @app.get("/login")
    async def login_page():
        return render("login.html")

    @app.post("/login")
    async def login_post(request: Request):
        if not _crm_repo:
            return JSONResponse({"ok": False, "error": "CRM не загружен"}, status_code=503)
        body = await request.json()
        username = body.get("username") or ""
        password = body.get("password") or ""
        if not username or not password:
            return JSONResponse({"ok": False, "error": "Введите логин и пароль"}, status_code=400)
        try:
            acc = _crm_repo.authenticate_account(username, password)
            if not acc:
                return JSONResponse({"ok": False, "error": "Неверный логин или пароль"}, status_code=403)
            ua = request.headers.get("user-agent", "")
            ip = request.client.host if request.client else ""
            token = _crm_repo.create_account_session(int(acc["id"]), ua, ip)
            resp = JSONResponse({"ok": True, "token": token,
                                 "account": {"id": acc["id"], "username": acc["username"], "display_name": acc["display_name"] if acc["display_name"] else "", "role": acc["role"], "can_access_panel": acc["can_access_panel"]}})
            resp.set_cookie("crm_session", token, httponly=True, max_age=86400, samesite="lax")
            resp.set_cookie("wp_session", token, httponly=True, max_age=86400, samesite="lax")
            return resp
        except Exception as exc:
            logger.error("Login error: %s", exc)
            return JSONResponse({"ok": False, "error": "Ошибка сервера"}, status_code=500)

    @app.get("/players")
    async def players_page(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("players.html")

    @app.get("/bans")
    async def bans_page(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("bans.html")

    @app.get("/logs")
    async def logs_page(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("logs.html")

    @app.get("/rooms")
    async def rooms_page(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("rooms.html")

    @app.get("/crm.js")
    async def crm_js():
        return FileResponse(str(HERE / "crm.js"))

    @app.get("/crm")
    async def crm_page(request: Request):
        if not _auth(request):
            return RedirectResponse(url="/login")
        return render("crm.html")

    # ─── Account API ────────────────────────────────────────────────

    @app.post("/api/register")
    async def api_register(request: Request):
        if not _crm_repo:
            return JSONResponse({"ok": False, "error": "CRM не загружен"}, status_code=503)
        body = await request.json()
        username = (body.get("username") or "").strip()
        password = body.get("password") or ""
        display_name = (body.get("display_name") or username).strip()
        try:
            _crm_repo.register_account(username, password, display_name)
            return {"ok": True}
        except Exception as exc:
            msg = str(exc)
            if "UNIQUE" in msg:
                msg = "Такой логин уже существует"
            return JSONResponse({"ok": False, "error": msg}, status_code=400)

    @app.post("/api/account/login")
    async def api_account_login(request: Request):
        if not _crm_repo:
            return JSONResponse({"ok": False, "error": "CRM не загружен"}, status_code=503)
        body = await request.json()
        try:
            acc = _crm_repo.authenticate_account(body.get("username", ""), body.get("password", ""))
            if not acc:
                return JSONResponse({"ok": False, "error": "Неверный логин или пароль"}, status_code=403)
            ua = request.headers.get("user-agent", "")
            ip = request.client.host if request.client else ""
            token = _crm_repo.create_account_session(int(acc["id"]), ua, ip)
            a = dict(acc)
            return {"ok": True, "token": token,
                    "account": {"id": a["id"], "username": a["username"], "display_name": a.get("display_name", ""), "role": a["role"], "can_access_panel": a["can_access_panel"]}}
        except Exception as exc:
            return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    @app.post("/api/account/logout")
    async def api_account_logout(request: Request):
        token = request.cookies.get("wp_session") or request.cookies.get("crm_session")
        if token and _crm_repo:
            try:
                _crm_repo.revoke_session(token)
            except Exception:
                pass
        return {"ok": True}

    @app.get("/api/account/profile")
    async def api_account_profile(request: Request):
        acc = _account(request)
        if not acc:
            return {"ok": False, "error": "Not logged in"}
        return {"ok": True, "account": {k: acc[k] for k in ("id","username","display_name","role","created_at","last_login_at")}}

    @app.post("/api/account/profile")
    async def api_account_profile_update(request: Request):
        acc = _account(request)
        if not acc:
            return JSONResponse({"error": "Not logged in"}, status_code=401)
        body = await request.json()
        display_name = (body.get("display_name") or "").strip()
        if display_name and _crm_repo:
            stamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            with _crm_repo.crm_conn() as conn:
                conn.execute("UPDATE accounts SET display_name=?,updated_at=? WHERE id=?", (display_name, stamp, acc["id"]))
        return {"ok": True}

    @app.get("/api/account/list")
    async def api_account_list(request: Request):
        acc = _account(request)
        if not acc or str(acc.get("role")) != "superadmin":
            return {"ok": False, "error": "Forbidden"}
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        rows = _crm_repo.list_accounts()
        return {"ok": True, "accounts": [dict(r) for r in rows]}

    @app.post("/api/account/approve")
    async def api_account_approve(request: Request):
        acc = _account(request)
        if not acc or str(acc.get("role")) != "superadmin":
            return {"ok": False, "error": "Forbidden"}
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        body = await request.json()
        _crm_repo.set_account_access(int(body["account_id"]), bool(body.get("grant", True)), int(acc["id"]))
        return {"ok": True}

    # ─── CRM API ────────────────────────────────────────────────────

    @app.get("/api/crm/stats")
    async def crm_stats(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        with _crm_repo.crm_conn() as conn:
            players = conn.execute("SELECT COUNT(*) cnt FROM player_cache").fetchone()["cnt"]
        sync = _crm_repo.sync_status()
        return {"ok": True, "stats": {"players": players}, "sync": sync}

    @app.post("/api/crm/sync")
    async def crm_sync(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        body = await request.json() if request.headers.get("content-length") else {}
        force = body.get("force", False)
        ok = _crm_repo.start_background_sync(force_full=force)
        return {"ok": ok}

    @app.get("/api/crm/players")
    async def crm_players(request: Request, q: str = "", page: int = 1, sort: str = "last_seen_desc", profiled: bool = False, banned: bool = False):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        result = _crm_repo.list_players(query=q, page=page, sort=sort, only_profiled=profiled, only_banned=banned)
        # Convert Row objects to dicts
        items = []
        for row in result["items"]:
            d = dict(row)
            d["last_seen_fmt"] = (row["last_seen"] or "")[:16].replace("T", " ")
            items.append(d)
        return {"ok": True, "items": items, "total": result["total"], "page": result["page"], "pages": result["pages"]}

    @app.get("/api/crm/player/{hdid}")
    async def crm_player_detail(request: Request, hdid: str):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        summary = _crm_repo._summary_from_cache_row(None)
        with _crm_repo.crm_conn() as conn:
            row = conn.execute("SELECT * FROM player_cache WHERE hdid=?", (hdid,)).fetchone()
            if row:
                ipids = [r["ipid"] for r in conn.execute("SELECT ipid FROM player_cache_ipids WHERE hdid=?", (hdid,)).fetchall()]
                summary = _crm_repo._summary_from_cache_row(row, ipids)
            bans = _crm_repo.get_player_bans(hdid)
            profiles = _crm_repo.get_player_profiles(hdid)
            access = _crm_repo.get_player_access_rule(hdid)
        return {
            "ok": True,
            "player": {
                "hdid": hdid,
                "first_seen": summary.get("first_seen"),
                "last_seen": summary.get("last_seen"),
                "connect_count": summary.get("connect_count", 0),
                "failed_count": summary.get("failed_count", 0),
                "last_ip": summary.get("last_ip", ""),
                "last_ipid": summary.get("last_ipid"),
                "last_ooc_name": summary.get("last_ooc_name", ""),
                "last_ic_name": summary.get("last_ic_name", ""),
                "last_char_name": summary.get("last_char_name", ""),
                "last_hub_name": summary.get("last_hub_name", ""),
                "ooc_names": list(summary.get("ooc_names", set())),
                "ic_names": list(summary.get("ic_names", set())),
                "char_names": list(summary.get("char_names", set())),
                "hub_names": list(summary.get("hub_names", set())),
                "ip_addresses": list(summary.get("ip_addresses", set())),
                "known_ipids": list(summary.get("known_ipids", set())),
                "is_hdid_banned": summary.get("is_hdid_banned", 0),
                "is_ip_banned": summary.get("is_ip_banned", 0),
            },
            "bans": [dict(b) for b in bans],
            "profiles": [dict(p) for p in profiles],
            "access_rule": dict(access) if access else None,
        }

    @app.get("/api/crm/player/{hdid}/logs")
    async def crm_player_logs(request: Request, hdid: str, filter: str = "all", q: str = "", limit: int = 60):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        logs = _crm_repo.get_player_logs(hdid, log_filter=filter, query=q, limit=limit)
        return {"ok": True, "logs": logs}

    @app.get("/api/crm/player/{hdid}/connections")
    async def crm_player_connections(request: Request, hdid: str, limit: int = 30):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        conns = _crm_repo.get_player_connections(hdid, limit=limit)
        return {"ok": True, "connections": [dict(c) for c in conns]}

    @app.get("/api/crm/profiles")
    async def crm_profiles(request: Request, q: str = "", page: int = 1, sort: str = "updated_desc"):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        result = _crm_repo.list_profiles(query=q, page=page, sort=sort)
        items = [dict(r) for r in result["items"]]
        return {"ok": True, "items": items, "total": result["total"], "page": result["page"], "pages": result["pages"]}

    @app.get("/api/crm/profile/{profile_id}")
    async def crm_profile_get(request: Request, profile_id: int):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        profile = _crm_repo.get_profile(profile_id)
        if not profile:
            return {"ok": False, "error": "Not found"}
        hdids = _crm_repo.get_profile_hdids(profile_id)
        return {"ok": True, "profile": dict(profile), "hdids": [dict(h) for h in hdids]}

    @app.post("/api/crm/profile/save")
    async def crm_profile_save(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        body = await request.json()
        profile_id = _crm_repo.save_profile(body)
        return {"ok": True, "id": profile_id}

    @app.post("/api/crm/profile/delete")
    async def crm_profile_delete(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo:
            return {"ok": False, "error": "CRM не загружен"}
        body = await request.json()
        _crm_repo.delete_profile(int(body["id"]))
        return {"ok": True}

    # ─── CRM GA Access API ──────────────────────────────────────────

    def _crm_acc(request):
        """Helper: returns (account, error_response)"""
        acc = _account(request)
        if not acc or not _crm_repo:
            return None, JSONResponse({"error": "Unauthorized"}, status_code=401)
        if not _crm_repo.has_panel_access(acc):
            return None, JSONResponse({"error": "No access"}, status_code=403)
        return acc, None

    @app.get("/api/crm/player/{hdid}/access")
    async def crm_player_access(request: Request, hdid: str):
        acc, err = _crm_acc(request)
        if err: return err
        rule = _crm_repo.get_player_access_rule(hdid)
        can_open = _crm_repo.can_open_player_card(acc, hdid)
        pending = None
        if not can_open:
            with _crm_repo.crm_conn() as conn:
                row = conn.execute(
                    "SELECT id FROM player_access_requests WHERE hdid=? AND requester_account_id=? AND status='pending'",
                    (hdid, int(acc["id"]))
                ).fetchone()
                if row: pending = row["id"]
        return {
            "ok": True,
            "rule": dict(rule) if rule else None,
            "can_open": can_open,
            "is_superadmin": str(acc.get("role")) == "superadmin",
            "pending_request_id": pending,
        }

    @app.post("/api/crm/player/{hdid}/access-rule")
    async def crm_player_access_rule(request: Request, hdid: str):
        acc, err = _crm_acc(request)
        if err: return err
        if str(acc.get("role")) != "superadmin":
            return JSONResponse({"error": "Only superadmin"}, status_code=403)
        body = await request.json()
        requires = bool(body.get("requires_ga_accept", True))
        _crm_repo.set_player_access_rule(hdid, requires, int(acc["id"]))
        return {"ok": True}

    @app.post("/api/crm/player/{hdid}/access-request")
    async def crm_player_access_request(request: Request, hdid: str):
        acc, err = _crm_acc(request)
        if err: return err
        if str(acc.get("role")) == "superadmin":
            return {"ok": True, "granted": True}
        rule = _crm_repo.get_player_access_rule(hdid)
        if rule and int(rule["requires_ga_accept"] or 0):
            status, req_id = _crm_repo.request_player_access(hdid, int(acc["id"]))
            return {"ok": True, "request_id": req_id, "status": status, "granted": status == "approved"}
        return {"ok": True, "granted": True}

    @app.post("/api/crm/access-request/resolve")
    async def crm_access_request_resolve(request: Request):
        acc, err = _crm_acc(request)
        if err: return err
        if str(acc.get("role")) != "superadmin":
            return JSONResponse({"error": "Only superadmin"}, status_code=403)
        body = await request.json()
        _crm_repo.resolve_player_access_request(int(body["request_id"]), int(acc["id"]), bool(body.get("approve", True)))
        return {"ok": True}

    @app.post("/api/crm/player/session/start")
    async def crm_player_session_start(request: Request):
        acc, err = _crm_acc(request)
        if err: return err
        body = await request.json()
        hdid = body.get("hdid")
        if not hdid:
            return JSONResponse({"error": "Missing hdid"}, status_code=400)
        if not _crm_repo.can_open_player_card(acc, hdid):
            return JSONResponse({"error": "Access denied"}, status_code=403)
        ua = request.headers.get("user-agent", "")
        ip = request.client.host if request.client else ""
        _crm_repo.create_player_card_session(hdid, int(acc["id"]), ip, ua)
        return {"ok": True}

    @app.post("/api/crm/player/session/ping")
    async def crm_player_session_ping(request: Request):
        acc, err = _crm_acc(request)
        if err: return err
        body = await request.json()
        hdid = body.get("hdid")
        if hdid:
            try:
                _crm_repo.touch_player_card_session(hdid, int(acc["id"]))
            except Exception:
                pass
        return {"ok": True}

    @app.post("/api/crm/player/session/end")
    async def crm_player_session_end(request: Request):
        acc, err = _crm_acc(request)
        if err: return err
        body = await request.json()
        hdid = body.get("hdid")
        if hdid:
            try:
                _crm_repo.end_player_card_session(hdid, int(acc["id"]), body.get("reason", "manual"))
            except Exception:
                pass
        return {"ok": True}

    # ─── API ─────────────────────────────────────────────────────────

    @app.get("/api/ping")
    async def api_ping():
        return {"ok": True, "server": _server_ref is not None}

    @app.get("/api/stats")
    async def api_stats(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        srv = _server_ref
        cm = srv.client_manager
        areas = []
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                areas.append({
                    "hub": hub.name, "hub_id": hub.id,
                    "id": area.id, "name": area.name,
                    "players": len([c for c in area.clients if c.char_id != -1]),
                    "music": area.music or "", "background": area.background or "",
                })
        players = []
        for c in cm.clients:
            players.append({
                "id": c.id, "name": c.name, "char_name": c.char_name,
                "area": c.area.name if c.area else "",
                "area_id": c.area.id if c.area else -1,
                "hub": c.area.area_manager.name if c.area and hasattr(c.area, "area_manager") else "",
                "ipid": c.ipid, "ip": getattr(c, "ip_address", ""),
                "hdid": getattr(c, "hdid", ""), "is_mod": c.is_mod,
                "is_muted": getattr(c, "is_muted", False),
                "is_ooc_muted": getattr(c, "is_ooc_muted", False),
                "disemvowel": getattr(c, "disemvowel", False),
                "shaken": getattr(c, "shaken", False),
                "rainbow": getattr(c, "rainbow", False),
                "char_id": c.char_id,
            })
        return {
            "player_count": srv.player_count, "total_clients": len(cm.clients),
            "uptime": time.time() - srv.start_time if hasattr(srv, "start_time") else 0,
            "areas": areas, "players": players,
            "mods": [p for p in players if p["is_mod"]],
            "hubs": [{"id": h.id, "name": h.name} for h in srv.hub_manager.hubs],
        }

    @app.get("/api/hubs")
    async def api_hubs(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        srv = _server_ref
        hubs = []
        for hub in srv.hub_manager.hubs:
            hubs.append({
                "id": hub.id, "name": hub.name,
                "areas": [{"id": a.id, "name": a.name} for a in hub.areas],
            })
        return {"hubs": hubs}

    @app.get("/api/logs")
    async def api_logs(request: Request, ipid: int = None, hub: int = None, area: int = None,
                       page: int = 1, limit: int = 50):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        offset = (page - 1) * limit
        where = ["t.type_name IN ('chat.ic','chat.ooc')"]
        params = []
        if ipid:
            where.append("a.ipid = ?"); params.append(ipid)
        if hub is not None:
            where.append("a.hub_id = ?"); params.append(hub)
        if area is not None:
            where.append("a.area_id = ?"); params.append(area)
        w = " AND ".join(where)
        with db._database_singleton.db as conn:
            rows = conn.execute(
                f"""SELECT a.event_time, a.ipid, a.area_name, a.hub_name,
                           a.char_name, a.ooc_name, a.ic_name, a.message, t.type_name
                    FROM area_events a
                    JOIN area_event_types t ON a.event_subtype = t.type_id
                    WHERE {w}
                    ORDER BY a.event_time DESC LIMIT ? OFFSET ?""",
                (*params, limit, offset),
            ).fetchall()
            total = conn.execute(
                f"SELECT COUNT(*) FROM area_events a JOIN area_event_types t ON a.event_subtype = t.type_id WHERE {w}",
                params,
            ).fetchone()[0]
        items = []
        for r in rows:
            items.append({
                "time": str(r["event_time"]), "ipid": r["ipid"],
                "area": r["area_name"], "hub": r["hub_name"],
                "char_name": r["char_name"], "ooc_name": r["ooc_name"],
                "message": r["message"], "type": r["type_name"],
            })
        return {"logs": items, "total": total, "page": page, "limit": limit}

    @app.get("/api/player/{ipid}")
    async def api_player_info(ipid: int, request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        client = _cli(ipid)
        info = {"online": client is not None}
        if client:
            info.update({
                "id": client.id, "name": client.name,
                "char_name": client.char_name, "showname": getattr(client, "showname", ""),
                "area": client.area.name if client.area else "",
                "area_id": client.area.id if client.area else -1,
                "hub": client.area.area_manager.name if client.area and hasattr(client.area, "area_manager") else "",
                "ipid": client.ipid, "ip": getattr(client, "ip_address", ""),
                "hdid": getattr(client, "hdid", ""),
                "is_mod": client.is_mod, "is_muted": getattr(client, "is_muted", False),
                "is_ooc_muted": getattr(client, "is_ooc_muted", False),
                "disemvowel": getattr(client, "disemvowel", False),
                "shaken": getattr(client, "shaken", False),
                "rainbow": getattr(client, "rainbow", False),
                "char_id": client.char_id, "pos": getattr(client, "pos", ""),
            })
        with db._database_singleton.db as conn:
            info["hdids"] = [r["hdid"] for r in conn.execute("SELECT hdid FROM hdids WHERE ipid=?", (ipid,)).fetchall()]
            name_rows = conn.execute(
                """SELECT ooc_name,COUNT(*) cnt FROM area_events WHERE ipid=? AND ooc_name IS NOT NULL AND ooc_name!=''
                   GROUP BY ooc_name ORDER BY cnt DESC LIMIT 20""", (ipid,)).fetchall()
            info["past_names"] = [{"name": r["ooc_name"], "count": r["cnt"]} for r in name_rows]
            stats = conn.execute("SELECT * FROM player_stats WHERE ipid=?", (ipid,)).fetchone()
            info["stats"] = dict(stats) if stats else {}
            # Если игрок онлайн, добавляем текущую сессию к времени
            if client and info["stats"].get("last_connect"):
                from datetime import datetime as dt2
                lc = info["stats"]["last_connect"]
                if isinstance(lc, str):
                    # Пробуем разные форматы — с микросекундами и без
                    for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
                        try:
                            lc = dt2.strptime(lc, fmt)
                            break
                        except ValueError:
                            continue
                    else:
                        lc = None
                if lc:
                    elapsed = int((dt2.utcnow() - lc).total_seconds())
                    if elapsed > 0:
                        info["stats"]["playtime_seconds"] = (info["stats"].get("playtime_seconds") or 0) + elapsed
            warns = conn.execute("SELECT * FROM player_warnings WHERE ipid=? ORDER BY warned_at DESC", (ipid,)).fetchall()
            info["warnings"] = [dict(r) for r in warns]
        return info

    @app.post("/api/player/kick")
    async def api_player_kick(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"])
        client = _cli(ipid)
        if not client:
            return JSONResponse({"ok": False, "error": "Игрок не в сети"})
        client.send_command("KB", body.get("reason", "Kicked via panel"))
        client.disconnect()
        _log_admin("kick", {"ipid": ipid, "name": client.name})
        return {"ok": True}

    @app.post("/api/player/ban")
    async def api_player_ban(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"])
        reason = body.get("reason", "Banned via panel")
        hours = int(body.get("hours", 0))
        unban_date = None
        if hours > 0:
            unban_date = (datetime.utcnow() + timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        class _PB: name = "Panel"; ipid = 0
        ban_id = db.ban(ipid, reason, ban_type="ipid", banned_by=_PB(), unban_date=unban_date)
        client = _cli(ipid)
        if client:
            client.send_command("KB", reason)
            client.disconnect()
        _log_admin("ban", {"ipid": ipid, "reason": reason, "hours": hours, "ban_id": ban_id})
        broadcast_event("ban", {"time": time.strftime("%H:%M:%S"), "who": "Panel", "what": f"Забанил IPID {ipid}: {reason}"})
        return {"ok": True, "ban_id": ban_id}

    @app.post("/api/player/mute")
    async def api_player_mute(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); mtype = body.get("type", "ic")
        client = _cli(ipid)
        if not client:
            return JSONResponse({"ok": False, "error": "Игрок не в сети"})
        if mtype == "ic":
            client.is_muted = not client.is_muted; state = "muted" if client.is_muted else "unmuted"
        else:
            client.is_ooc_muted = not client.is_ooc_muted; state = "ooc_muted" if client.is_ooc_muted else "ooc_unmuted"
        _log_admin("mute", {"ipid": ipid, "type": mtype, "state": state})
        return {"ok": True, "state": state}

    @app.post("/api/player/fun")
    async def api_player_fun(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); cmd = body.get("command")
        client = _cli(ipid)
        if not client:
            return JSONResponse({"ok": False, "error": "Игрок не в сети"})
        toggles = {"disemvowel": "disemvowel", "shake": "shaken", "rainbow": "rainbow"}
        if cmd in toggles:
            attr = toggles[cmd]; old = getattr(client, attr, False); setattr(client, attr, not old)
            _log_admin(f"fun_{cmd}", {"ipid": ipid, "state": not old})
            return {"ok": True, "state": "включено" if not old else "выключено"}
        if cmd == "undisemvowel": client.disemvowel = False; return {"ok": True, "state": "выключено"}
        if cmd == "unshake": client.shaken = False; return {"ok": True, "state": "выключено"}
        return JSONResponse({"ok": False, "error": "Неизвестная команда"})

    @app.post("/api/player/impersonate_ic")
    async def api_impersonate_ic(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); message = body.get("message", "").strip()
        if not message:
            return JSONResponse({"ok": False, "error": "Пустое сообщение"})
        client = _cli(ipid)
        if not client:
            return JSONResponse({"ok": False, "error": "Игрок не в сети"})
        try:
            client.area.send_ic(client=client, msg=message, pos=client.pos, cid=client.char_id, showname=client.showname)
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)})
        _log_admin("impersonate_ic", {"ipid": ipid, "name": client.name})
        return {"ok": True}

    @app.post("/api/player/impersonate_ooc")
    async def api_impersonate_ooc(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); message = body.get("message", "").strip()
        if not message:
            return JSONResponse({"ok": False, "error": "Пустое сообщение"})
        client = _cli(ipid)
        if not client:
            return JSONResponse({"ok": False, "error": "Игрок не в сети"})
        client.area.send_command("CT", f"[Panel]{client.name}", message)
        _log_admin("impersonate_ooc", {"ipid": ipid, "name": client.name})
        return {"ok": True}

    @app.post("/api/player/warn")
    async def api_player_warn(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); reason = body.get("reason", "").strip()
        if not reason:
            return JSONResponse({"ok": False, "error": "Укажите причину"})
        with db._database_singleton.db as conn:
            conn.execute("INSERT INTO player_warnings(ipid, warned_by, reason) VALUES (?, 'Panel', ?)", (ipid, reason))
        client = _cli(ipid)
        if client:
            client.send_ooc(f"[Предупреждение] {reason}")
        _log_admin("warn", {"ipid": ipid, "reason": reason})
        return {"ok": True}

    @app.post("/api/player/warn/delete")
    async def api_player_warn_delete(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); wid = int(body["warning_id"])
        with db._database_singleton.db as conn:
            conn.execute("DELETE FROM player_warnings WHERE id=? AND ipid=?", (wid, ipid))
        _log_admin("warn_delete", {"ipid": ipid, "warning_id": wid})
        return {"ok": True}

    @app.get("/api/achievements")
    async def api_achievements(request: Request, ipid: int = None):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        from server import achievements as ach
        if ipid:
            return {"achievements": ach.get_player_achievements(ipid)}
        return {"achievements": list(ach.get_all_defs().values())}

    @app.post("/api/achievements/grant")
    async def api_achievements_grant(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); achievement_id = body["achievement_id"]
        client = _cli(ipid)
        from server import achievements as ach
        with db._database_singleton.db as conn:
            conn.execute("INSERT OR IGNORE INTO player_achievements(achievement_id, ipid) VALUES (?, ?)", (achievement_id, ipid))
        if client:
            adef = ach.get_achievement(achievement_id)
            if adef:
                client.send_ooc(f"[Достижение] Тебе выдано: {adef['name']} — {adef['description']}")
        _log_admin("achievement_grant", {"ipid": ipid, "achievement_id": achievement_id})
        return {"ok": True}

    @app.post("/api/achievements/revoke")
    async def api_achievements_revoke(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ipid = int(body["ipid"]); achievement_id = body["achievement_id"]
        with db._database_singleton.db as conn:
            conn.execute("DELETE FROM player_achievements WHERE achievement_id=? AND ipid=?", (achievement_id, ipid))
        _log_admin("achievement_revoke", {"ipid": ipid, "achievement_id": achievement_id})
        return {"ok": True}

    @app.post("/api/unban")
    async def api_unban(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        ok = db.unban(int(body["ban_id"]))
        return {"ok": ok}

    @app.post("/api/send_ooc")
    async def api_send_ooc(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        text = (body.get("text") or "").strip()
        if not text:
            return JSONResponse({"ok": False, "error": "Пустое сообщение"})
        _server_ref.send_all_cmd_pred("CT", "<dollar>G[Panel]", text)
        return {"ok": True}

    @app.get("/api/bans")
    async def api_bans(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        bans = []
        for b in db.recent_bans(50):
            bans.append({
                "ban_id": b.ban_id, "ban_date": str(b.ban_date),
                "unban_date": str(b.unban_date) if b.unban_date else None,
                "banned_by": b.banned_by, "banned_by_name": b.banned_by_name,
                "reason": b.reason,
            })
        return {"bans": bans}

    @app.get("/api/export/{type}")
    async def api_export(type: str, request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        srv = _server_ref
        out = io.StringIO()
        w = csv.writer(out)
        if type == "players":
            w.writerow(["ID", "OOC Name", "Character", "Area", "Hub", "IPID", "IP", "HDID", "Mod", "Muted"])
            for c in srv.client_manager.clients:
                w.writerow([c.id, c.name, c.char_name, c.area.name if c.area else "",
                            c.area.area_manager.name if c.area and hasattr(c.area, "area_manager") else "",
                            c.ipid, getattr(c, "ip_address", ""), getattr(c, "hdid", ""),
                            c.is_mod, getattr(c, "is_muted", False)])
            fn = "players.csv"
        elif type == "bans":
            w.writerow(["Ban ID", "Date", "Banner", "Reason", "Unban Date"])
            for b in db.recent_bans(200):
                w.writerow([b.ban_id, str(b.ban_date), b.banned_by_name or "", b.reason, str(b.unban_date) if b.unban_date else ""])
            fn = "bans.csv"
        elif type == "logs":
            w.writerow(["Time", "Type", "OOC Name", "Char Name", "Area", "Hub", "Message"])
            with db._database_singleton.db as conn:
                rows = conn.execute(
                    """SELECT a.event_time, t.type_name, a.ooc_name, a.char_name, a.area_name, a.hub_name, a.message
                       FROM area_events a JOIN area_event_types t ON a.event_subtype = t.type_id
                       WHERE t.type_name IN ('chat.ic','chat.ooc') ORDER BY a.event_time DESC LIMIT 2000"""
                ).fetchall()
                for r in rows:
                    w.writerow([r[0], r[1], r[2] or "", r[3] or "", r[4] or "", r[5] or "", r[6] or ""])
            fn = "logs.csv"
        else:
            return JSONResponse({"error": "Unknown type"}, status_code=400)
        out.seek(0)
        return StreamingResponse(iter([out.getvalue()]), media_type="text/csv",
                                 headers={"Content-Disposition": f"attachment; filename={fn}"})

    @app.post("/api/execute")
    async def api_execute(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        cmd_text = body.get("command", "").strip()
        if not cmd_text:
            return JSONResponse({"ok": False, "error": "Пустая команда"})
        srv = _server_ref
        try:
            if cmd_text.startswith("/"):
                cmd_text = cmd_text[1:]
            parts = cmd_text.split(None, 1)
            cmd_name = parts[0].lower() if parts else ""
            cmd_arg = parts[1] if len(parts) > 1 else ""
            from server import commands as cmd_mod
            import types
            mock = types.SimpleNamespace(
                server=srv, is_mod=True, name="Panel", char_name="Panel",
                area=srv.hub_manager.hubs[0].areas[0] if srv.hub_manager.hubs else None,
                send_ooc=lambda msg: srv.send_all_cmd_pred("CT", "<dollar>G[Panel]", msg),
                send_command=lambda *a: None,
                ipid=0, hdid="",
                muted_global=False, muted_adverts=False,
                is_muted=False, is_ooc_muted=False, pm_mute=False,
                disemvowel=False, shaken=False, rainbow=False,
            )
            try:
                cmd_mod.call(mock, cmd_name, cmd_arg)
                _log_admin("execute", {"command": cmd_text})
                return {"ok": True, "result": "Команда выполнена"}
            except Exception as e:
                return {"ok": True, "result": f"Ошибка: {e}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ─── Room Map API ────────────────────────────────
    @app.get("/api/room-map")
    async def api_room_map(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        srv = _server_ref
        hubs = []
        for hub in srv.hub_manager.hubs:
            areas_list = []
            for area in hub.areas:
                areas_list.append({
                    "id": area.id, "name": area.name,
                    "players": len([c for c in area.clients if c.char_id != -1]),
                    "music": area.music or "",
                    "background": area.background or "",
                    "status": getattr(area, "status", "IDLE"),
                    "desc": getattr(area, "desc", ""),
                })
            hubs.append({"id": hub.id, "name": hub.name, "areas": areas_list})
        return {"hubs": hubs}

    # ─── Room Editor ─────────────────────────────────
    @app.post("/api/area/update")
    async def api_area_update(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        area_id = int(body["area_id"])
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                if area.id == area_id:
                    if "music" in body:
                        area.music = body["music"]
                    if "background" in body:
                        area.background = body["background"]
                    _log_admin("area_update", {"area_id": area_id, "changes": {k: body[k] for k in ("music","background") if k in body}})
                    return {"ok": True, "area": {"id": area.id, "name": area.name, "music": area.music, "background": area.background}}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    # ─── Hub/Area Management ─────────────────────────
    @app.post("/api/area/rename")
    async def api_area_rename(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        area_id = int(body.get("area_id", -1))
        name = (body.get("name") or "").strip()
        if not name:
            return JSONResponse({"ok": False, "error": "Укажите название"})
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                if area.id == area_id:
                    area.name = name
                    _log_admin("area_rename", {"area_id": area_id, "name": name})
                    return {"ok": True}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    @app.post("/api/hub/create")
    async def api_hub_create(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        name = (body.get("name") or "").strip()
        if not name:
            return JSONResponse({"ok": False, "error": "Укажите название хаба"})
        srv = _server_ref
        hm = srv.hub_manager
        import importlib
        import server.area_manager as am
        new_hub = am.AreaManager(hm, name)
        hm.hubs.append(new_hub)
        _log_admin("hub_create", {"name": name})
        return {"ok": True, "hub": {"id": new_hub.id, "name": new_hub.name}}

    @app.post("/api/hub/rename")
    async def api_hub_rename(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        hub_id = int(body.get("hub_id", -1))
        name = (body.get("name") or "").strip()
        if not name:
            return JSONResponse({"ok": False, "error": "Укажите название"})
        srv = _server_ref
        try:
            hub = srv.hub_manager.get_hub_by_id(hub_id)
            hub.name = name
            _log_admin("hub_rename", {"hub_id": hub_id, "name": name})
            return {"ok": True}
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)})

    @app.post("/api/area/create")
    async def api_area_create(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        hub_id = int(body.get("hub_id", -1))
        name = (body.get("name") or "").strip()
        if not name:
            return JSONResponse({"ok": False, "error": "Укажите название зоны"})
        srv = _server_ref
        try:
            hub = srv.hub_manager.get_hub_by_id(hub_id)
            import server.area as ar
            new_area = ar.Area(hub, name)
            hub.areas.append(new_area)
            _log_admin("area_create", {"hub_id": hub_id, "name": name})
            return {"ok": True, "area": {"id": new_area.id, "name": new_area.name}}
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)})

    @app.post("/api/area/delete")
    async def api_area_delete(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        area_id = int(body.get("area_id", -1))
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for i, area in enumerate(hub.areas):
                if area.id == area_id:
                    hub.areas.pop(i)
                    _log_admin("area_delete", {"area_id": area_id})
                    return {"ok": True}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    @app.post("/api/hub/delete")
    async def api_hub_delete(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        hub_id = int(body.get("hub_id", -1))
        srv = _server_ref
        if hub_id == 0:
            return JSONResponse({"ok": False, "error": "Нельзя удалить первый хаб"})
        for i, hub in enumerate(srv.hub_manager.hubs):
            if hub.id == hub_id:
                clients = hub.clients.copy()
                for c in clients:
                    c.set_area(srv.hub_manager.hubs[0].default_area())
                srv.hub_manager.hubs.pop(i)
                _log_admin("hub_delete", {"hub_id": hub_id})
                return {"ok": True}
        return JSONResponse({"ok": False, "error": "Хаб не найден"}, status_code=404)

    @app.get("/api/area/{area_id}/prefs")
    async def api_area_prefs(area_id: int, request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                if area.id == area_id:
                    bools = {}
                    for key, val in area.__dict__.items():
                        if isinstance(val, bool):
                            bools[key] = val
                    return {"prefs": bools}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    @app.post("/api/area/{area_id}/prefs")
    async def api_area_prefs_save(area_id: int, request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        prefs = body.get("prefs", {})
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                if area.id == area_id:
                    for key, val in prefs.items():
                        if hasattr(area, key) and isinstance(getattr(area, key), bool):
                            setattr(area, key, bool(val))
                    _log_admin("area_prefs", {"area_id": area_id, "prefs": prefs})
                    return {"ok": True}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    @app.post("/api/area/bulk-update")
    async def api_area_bulk_update(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        area_id = int(body.get("area_id", -1))
        srv = _server_ref
        for hub in srv.hub_manager.hubs:
            for area in hub.areas:
                if area.id == area_id:
                    for key in ("background", "music", "desc", "status"):
                        if key in body:
                            setattr(area, key, body[key])
                    _log_admin("area_bulk_update", {"area_id": area_id, "changes": body})
                    return {"ok": True}
        return JSONResponse({"ok": False, "error": "Зона не найдена"}, status_code=404)

    # ─── Player Messages (Surveillance) ─────────────
    @app.get("/api/player/{ipid}/messages")
    async def api_player_messages(ipid: int, request: Request, limit: int = 50):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        with db._database_singleton.db as conn:
            rows = conn.execute(
                """SELECT a.event_time, t.type_name, a.area_name, a.hub_name,
                          a.char_name, a.ooc_name, a.message
                   FROM area_events a JOIN area_event_types t ON a.event_subtype = t.type_id
                   WHERE a.ipid = ? AND t.type_name IN ('chat.ic','chat.ooc')
                   ORDER BY a.event_time DESC LIMIT ?""",
                (ipid, limit),
            ).fetchall()
        messages = []
        for r in reversed(rows):
            messages.append({
                "time": str(r["event_time"]), "type": r["type_name"],
                "area": r["area_name"], "hub": r["hub_name"],
                "char_name": r["char_name"], "ooc_name": r["ooc_name"],
                "message": r["message"],
            })
        return {"messages": messages}

    # ─── Connection Graph ───────────────────────────
    @app.get("/api/connections/{ipid}")
    async def api_connections(ipid: int, request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        with db._database_singleton.db as conn:
            hdids = [r["hdid"] for r in conn.execute("SELECT hdid FROM hdids WHERE ipid=?", (ipid,)).fetchall()]
            related = set()
            edges = []
            nodes = [{"id": f"ipid:{ipid}", "label": f"IPID {ipid}", "type": "central"}]
            for hdid in hdids:
                nodes.append({"id": f"hdid:{hdid}", "label": f"HDID {hdid[:16]}...", "type": "hdid"})
                edges.append({"source": f"ipid:{ipid}", "target": f"hdid:{hdid}"})
                others = conn.execute("SELECT ipid FROM hdids WHERE hdid=? AND ipid!=?", (hdid, ipid)).fetchall()
                for o in others:
                    oid = o["ipid"]
                    if oid not in related:
                        related.add(oid)
                        nodes.append({"id": f"ipid:{oid}", "label": f"IPID {oid}", "type": "related"})
                        edges.append({"source": f"hdid:{hdid}", "target": f"ipid:{oid}"})
                        name_row = conn.execute(
                            "SELECT ooc_name FROM area_events WHERE ipid=? AND ooc_name IS NOT NULL AND ooc_name!='' ORDER BY event_time DESC LIMIT 1",
                            (oid,)).fetchone()
                        if name_row:
                            nodes[-1]["label"] = f"{name_row['ooc_name']} (IPID {oid})"
        return {"nodes": nodes, "edges": edges}

    # ─── Leaderboard ────────────────────────────────
    @app.get("/api/leaderboard")
    async def api_leaderboard(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        with db._database_singleton.db as conn:
            rows = conn.execute(
                """SELECT p.ipid, p.playtime_seconds, p.ic_messages, p.ooc_messages, p.logins,
                          (SELECT ooc_name FROM area_events WHERE ipid=p.ipid AND ooc_name IS NOT NULL AND ooc_name!=''
                           ORDER BY event_time DESC LIMIT 1) as name
                   FROM player_stats p ORDER BY p.playtime_seconds DESC LIMIT 50"""
            ).fetchall()
        leaders = []
        for i, r in enumerate(rows):
            leaders.append({
                "rank": i + 1,
                "ipid": r["ipid"],
                "name": r["name"] or f"IPID {r['ipid']}",
                "play_time": r["playtime_seconds"],
                "play_time_hr": round(r["playtime_seconds"] / 3600, 1) if r["playtime_seconds"] else 0,
                "messages": (r["ic_messages"] or 0) + (r["ooc_messages"] or 0),
                "connections": r["logins"],
            })
        return {"leaders": leaders}

    # ─── Dashboard Config (Widgets) ─────────────────
    @app.get("/api/dashboard/config")
    async def api_dashboard_config(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        try:
            with db._database_singleton.db as conn:
                row = conn.execute("SELECT event_data FROM misc_events WHERE event_subtype IN (SELECT type_id FROM misc_event_types WHERE type_name='dashboard_config') ORDER BY event_time DESC LIMIT 1").fetchone()
                if row:
                    return {"config": json.loads(row["event_data"])}
        except Exception:
            pass
        return {"config": {"widgets": ["graph", "areas", "hubs", "ooc", "leaderboard"]}}

    @app.post("/api/dashboard/config")
    async def api_dashboard_config_save(request: Request):
        if not _auth(request):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        body = await request.json()
        db.log_misc("dashboard_config", data=body.get("config", {}))
        return {"ok": True}

    @app.websocket("/ws")
    async def ws_endpoint(ws: WebSocket):
        if ws.cookies.get("token") != _config.get("password"):
            await ws.close(code=4001)
            return
        await ws.accept()
        _ws_clients.add(ws)
        try:
            while True:
                await ws.receive_text()
        except WebSocketDisconnect:
            pass
        finally:
            _ws_clients.discard(ws)

    return app


async def run_webpanel(server):
    cfg = server.config.get("webpanel", {})
    if not cfg.get("enabled"):
        return
    import uvicorn
    config = uvicorn.Config(
        make_app(server, cfg),
        host=cfg.get("host", "127.0.0.1"),
        port=int(cfg.get("port", 8080)),
        log_level="warning",
        loop="asyncio",
    )
    sv = uvicorn.Server(config)
    logger.info("Web panel starting on %s:%s", cfg.get("host"), cfg.get("port"))
    await sv.serve()
